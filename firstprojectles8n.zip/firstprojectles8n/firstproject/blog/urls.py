from django.urls import path
from blog.views import post_list, post_update, post_create, post_delete, post_detail


urlpatterns = [
    path('', post_list),
    path('update/', post_update),
    path('create/', post_create),
    path('delete/', post_delete),
    path('detail/<int:id>/', post_detail)
]